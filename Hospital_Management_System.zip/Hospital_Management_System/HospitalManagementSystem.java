// HospitalManagementSystem.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class HospitalManagementSystem extends JFrame implements ActionListener {
    JButton patientBtn, appointmentBtn, ehrBtn, billingBtn, inventoryBtn, staffBtn, exitBtn;

    public HospitalManagementSystem() {
        setTitle("Hospital Management System");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Hospital Management Dashboard", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        add(titleLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(3, 2, 20, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        patientBtn = new JButton("Patient Registration");
        appointmentBtn = new JButton("Appointment Scheduling");
        ehrBtn = new JButton("Electronic Health Records");
        billingBtn = new JButton("Billing and Invoicing");
        inventoryBtn = new JButton("Inventory Management");
        staffBtn = new JButton("Staff Management");

        JButton[] buttons = { patientBtn, appointmentBtn, ehrBtn, billingBtn, inventoryBtn, staffBtn };
        for (JButton btn : buttons) {
            btn.setFont(new Font("Segoe UI", Font.PLAIN, 16));
            btn.setBackground(new Color(0, 123, 255));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
            buttonPanel.add(btn);
        }

        add(buttonPanel, BorderLayout.CENTER);

        exitBtn = new JButton("Exit Application");
        exitBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        exitBtn.setBackground(Color.RED);
        exitBtn.setForeground(Color.WHITE);
        exitBtn.setFocusPainted(false);
        exitBtn.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(exitBtn, BorderLayout.SOUTH);

        patientBtn.addActionListener(this);
        appointmentBtn.addActionListener(this);
        ehrBtn.addActionListener(this);
        billingBtn.addActionListener(this);
        inventoryBtn.addActionListener(this);
        staffBtn.addActionListener(this);
        exitBtn.addActionListener(e -> System.exit(0));

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == patientBtn) new PatientModule();
        else if (e.getSource() == appointmentBtn) new AppointmentModule();
        else if (e.getSource() == ehrBtn) new EHRModule();
        else if (e.getSource() == billingBtn) new BillingModule();
        else if (e.getSource() == inventoryBtn) new InventoryModule();
        else if (e.getSource() == staffBtn) new StaffModule();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(HospitalManagementSystem::new);
    }
}

// PatientModule.java
class PatientModule extends JFrame {
    JTextField nameField, ageField, genderField, contactField, addressField;

    PatientModule() {
        setTitle("Patient Registration");
        setSize(350, 300);
        setLayout(new GridLayout(6, 2, 10, 10));

        add(new JLabel("Name:"));
        nameField = new JTextField();
        add(nameField);

        add(new JLabel("Age:"));
        ageField = new JTextField();
        add(ageField);

        add(new JLabel("Gender:"));
        genderField = new JTextField();
        add(genderField);

        add(new JLabel("Contact:"));
        contactField = new JTextField();
        add(contactField);

        add(new JLabel("Address:"));
        addressField = new JTextField();
        add(addressField);

        JButton submit = new JButton("Register");
        submit.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Patient Registered Successfully!");
            dispose();
        });
        add(submit);

        setVisible(true);
    }
}

// AppointmentModule.java
class AppointmentModule extends JFrame {
    JTextField patientIdField, doctorField, dateField, timeField;

    AppointmentModule() {
        setTitle("Appointment Scheduling");
        setSize(350, 250);
        setLayout(new GridLayout(5, 2, 10, 10));

        add(new JLabel("Patient ID:"));
        patientIdField = new JTextField();
        add(patientIdField);

        add(new JLabel("Doctor Name:"));
        doctorField = new JTextField();
        add(doctorField);

        add(new JLabel("Date (dd/mm/yyyy):"));
        dateField = new JTextField();
        add(dateField);

        add(new JLabel("Time (hh:mm):"));
        timeField = new JTextField();
        add(timeField);

        JButton book = new JButton("Book Appointment");
        book.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Appointment Scheduled!");
            dispose();
        });
        add(book);

        setVisible(true);
    }
}

// EHRModule.java
class EHRModule extends JFrame {
    JTextArea recordArea;

    EHRModule() {
        setTitle("Electronic Health Records");
        setSize(450, 350);
        setLayout(new BorderLayout());

        recordArea = new JTextArea("Enter patient diagnosis, prescription, and notes here...");
        add(new JScrollPane(recordArea), BorderLayout.CENTER);

        JButton save = new JButton("Save Record");
        save.addActionListener(e -> JOptionPane.showMessageDialog(this, "Record saved!"));
        add(save, BorderLayout.SOUTH);

        setVisible(true);
    }
}

// BillingModule.java
class BillingModule extends JFrame {
    JTextField patientId, serviceField, amountField;

    BillingModule() {
        setTitle("Billing and Invoicing");
        setSize(350, 220);
        setLayout(new GridLayout(4, 2, 10, 10));

        add(new JLabel("Patient ID:"));
        patientId = new JTextField();
        add(patientId);

        add(new JLabel("Service Rendered:"));
        serviceField = new JTextField();
        add(serviceField);

        add(new JLabel("Amount (INR):"));
        amountField = new JTextField();
        add(amountField);

        JButton generate = new JButton("Generate Bill");
        generate.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Invoice Generated: Rs. " + amountField.getText());
            dispose();
        });
        add(generate);

        setVisible(true);
    }
}

// InventoryModule.java
class InventoryModule extends JFrame {
    JTextField itemName, quantityField, expiryField;

    InventoryModule() {
        setTitle("Inventory Management");
        setSize(350, 220);
        setLayout(new GridLayout(4, 2, 10, 10));

        add(new JLabel("Item Name:"));
        itemName = new JTextField();
        add(itemName);

        add(new JLabel("Quantity:"));
        quantityField = new JTextField();
        add(quantityField);

        add(new JLabel("Expiry Date (mm/yyyy):"));
        expiryField = new JTextField();
        add(expiryField);

        JButton update = new JButton("Update Stock");
        update.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Inventory Updated for: " + itemName.getText());
            dispose();
        });
        add(update);

        setVisible(true);
    }
}

// StaffModule.java
class StaffModule extends JFrame {
    JTextField nameField, roleField, scheduleField;

    StaffModule() {
        setTitle("Staff Management");
        setSize(350, 220);
        setLayout(new GridLayout(4, 2, 10, 10));

        add(new JLabel("Name:"));
        nameField = new JTextField();
        add(nameField);

        add(new JLabel("Role (Doctor/Nurse/Admin):"));
        roleField = new JTextField();
        add(roleField);

        add(new JLabel("Shift Schedule:"));
        scheduleField = new JTextField();
        add(scheduleField);

        JButton add = new JButton("Add Staff");
        add.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Staff Added: " + nameField.getText());
            dispose();
        });
        add(add);

        setVisible(true);
    }
}
